# android_device_huawei_london
TWRP device tree for Huawei Y7 Prime 2018 (LDN-L21)
